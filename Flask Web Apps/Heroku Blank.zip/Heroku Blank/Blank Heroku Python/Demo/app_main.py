# import flask class object and
#render_template from flask framework
from flask import Flask, render_template

# create variable to store flask object
#instance of flask application
app=Flask(__name__)

# url for homepage
@app.route('/')
# home page
def home():
    return render_template("home.html")

@app.route('/about/')
# about page
def about():
    return render_template("about.html")


if __name__ == "__main__":
    app.run(debug=True)
